# v9.0

- refactor config 

# v8.0

- fix no accent color on maximized windows

# v4.0

- fix styles labeled wrong

# v3.0

- update package structure
- fix colors not always applied correctly

# v2.0

-  add variants for color schemes with pale accent colors

# v1.0

- initial release
