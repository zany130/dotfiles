#!/bin/sh
find -name \*.colors -print
