#include "breezeconfigwidget.h"
#include <KPluginFactory>

K_PLUGIN_CLASS_WITH_JSON(Breeze::ConfigWidget, "kcm_klassydecoration.json")

#include "kcm_breezedecoration.moc"
