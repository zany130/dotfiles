applet.currentConfigGroup = new Array("General");
applet.writeConfig("showPercentage", true);
applet.reloadConfig();

