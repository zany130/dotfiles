// literal downgrade in kwin made it so every script has to have a main.js or the script refuses to install????

print("Polonium INF: mfw");
