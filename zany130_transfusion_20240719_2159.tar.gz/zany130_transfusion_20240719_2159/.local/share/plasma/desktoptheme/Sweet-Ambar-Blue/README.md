### A dark and modern theme for KDE plasma

> This theme is based on the awesome [Helium](https://store.kde.org/p/998869/) theme

![Sweet preview](preview/preview.png)