# ChatAI-Plasmoid
A range of chatbots as Plasmoid for your KDE Plasma desktop 

![Screenshot_20240609_125938](https://github.com/DenysMb/ChatAI-Plasmoid/assets/33737137/348ec984-0254-4136-8fc8-08075d2a9b9a)

## Planned features
- [ ] Ability to let the user add a custom chatbot to the list
- [ ] Send messages when pressing Enter

## DuckDuckGo Chat
![Screenshot_20240609_125541](https://github.com/DenysMb/ChatAI-Plasmoid/assets/33737137/240ee703-ec9f-4605-86fe-f8ba507c90ff)

## ChatGPT
![Screenshot_20240609_125647](https://github.com/DenysMb/ChatAI-Plasmoid/assets/33737137/a173fc37-f400-426c-95e0-d6624e436dbe)

## HugginChat
![Screenshot_20240609_125742](https://github.com/DenysMb/ChatAI-Plasmoid/assets/33737137/8eca8a4b-0605-4696-bd66-7e1a5f571775)

## Widget Configuration

![Screenshot_20240609_123955](https://github.com/DenysMb/ChatAI-Plasmoid/assets/33737137/8d501fbe-d111-4ba5-a8f8-98e5bc022c30)
![Screenshot_20240609_123959](https://github.com/DenysMb/ChatAI-Plasmoid/assets/33737137/e7520a73-57b5-4f62-b3e6-8bd71b5ac752)

Colorful ChatGPT icon by [IconScout](https://iconscout.com/)

All other chat icons by [Icons8](https://icons8.com/)