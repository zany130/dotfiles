### CHANGELOG

#### Version 0.2
  - Mouse Gesture Support Ready
  - Cleaned up leftover Latte Dock files

#### Version 0.1
  - Support for Plasma Panels as of Plasma 6.0 RC2 ready.
